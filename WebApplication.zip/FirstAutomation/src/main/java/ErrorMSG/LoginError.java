/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ErrorMSG;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class LoginError {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        
        driver.get("http://localhost:7072/#/Login");
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));   
        
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        By toast = By.xpath("//div[@class='p-toast-message-content']");
        By userErorr = By.xpath("//span[@id='usernameHelp']");
        By passError = By.xpath("//span[@id='password1Help']");
        
        
        driver.findElement(signin).click(); 
        Thread.sleep(2000);
        String userError1 = driver.findElement(userErorr).getText();
        if(userError1.equals("Username is required !")) {
            System.out.println("Username error matched");
        } else {
            System.out.println("Username error did not matched");
        }
        
        
        String passError1 = driver.findElement(passError).getText();
        if(passError1.equals("Password is required !")) {
            System.out.println("Password error matched");
        } else {
            System.out.println("Password error did not matched");
        }
        
        
        if(userError1.equals("Username is required !")) {
            driver.findElement(username).sendKeys("asus");
            driver.findElement(signin).click(); 
            Thread.sleep(2000);
            if(passError1.equals("Password is required !")) {
                driver.findElement(password).sendKeys("nepal@123");
                Thread.sleep(2000);
                driver.findElement(signin).click(); 
            }
        }
        
        Thread.sleep(3000);
        String logText = driver.findElement(toast).getText();
        System.out.println(logText);
        
        if(logText.equals("Successfully LoggedIn !!")) {
            System.out.println("Login successfull");
        } else {
            System.out.println("Login failed");
        }
        
        
    }
}
