/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class CssSelector {
    public static void main(String[] args) throws InterruptedException {
        
        //running FirstTest.java file 
        //FirstTest.main(new String[]{});
        
        WebDriver driver = new ChromeDriver();
        
        //open url in browser
        driver.get("http://localhost:7072/#/Login");
        
        //to maximize the window 
        driver.manage().window().maximize();
        
        //using variable as a locator for elements
        By username = By.xpath("//input[@id='username']");
        By pname = By.xpath("//input[@id='name']");
        By pcode = By.xpath("//input[@id='code']");
        By pcategory = By.xpath("//input[@id='category']");
        By punit = By.xpath("//input[@id='unitGroup']");
        By next1 = By.xpath("//span[normalize-space()='Next']");       

        
        //find element using cssSelector
        driver.findElement(username).sendKeys("asus");
        driver.findElement(By.cssSelector("input#password1")).sendKeys("nepal@123");
        driver.findElement(By.cssSelector("button#signIn")).click(); 
        
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);    
        
        //comparing /assertion
        WebElement loginmsg = driver.findElement(By.xpath("//label[normalize-space()='Asus']"));
        String logmsg = loginmsg.getText(); 
        
        if(logmsg.equals("Asus"))
        {
          System.out.println("Login passed");
        }
        else
        {
           System.out.println("Login failed");
        }
        
        
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        //Thread.sleep(20000);

        driver.findElement(By.cssSelector("a#pnl_Product")).click();
        driver.findElement(By.cssSelector("a#subpnl_Product_Details")).click();
        driver.findElement(By.xpath("//span[normalize-space()='Add']")).click();
        driver.findElement(pname).sendKeys("jpt");
        driver.findElement(pcode).sendKeys("jpt123");
        driver.findElement(pcategory).sendKeys("Noodels");
        driver.findElement(punit).sendKeys("piec");
        driver.findElement(next1).click();

    }
}
