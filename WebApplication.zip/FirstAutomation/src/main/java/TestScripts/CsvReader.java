/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aman
 */
public class CsvReader {
    public static void main(String[] args) throws FileNotFoundException, IOException, CsvValidationException {
        
//      ------Reading CSV files------        
        CSVReader reader = new CSVReader(new FileReader("/home/aman/Users/Jmeter/login.csv"));
        
        String[] str;
        while((str=reader.readNext())!=null){
            for(String s : str) {
                System.out.print(s+" ");
            }
            System.out.println();
        }
        
        
//      ------Writing in CSV files------
        CSVWriter writer = new CSVWriter(new FileWriter("csv\\csvfile.csv"));
        String[] heading = {"Firstname","Lastname"};
        String[] data1 = {"Aman","Shrestha"};        
        String[] data2 = {"John","Tamang"};
        String[] data3 = {"KP","Oli"};
        String[] data4 = {"Mauri","Attack"};

        writer.writeNext(heading);
        writer.writeNext(data1);
        writer.writeNext(data2);
        writer.writeNext(data3);
        writer.writeNext(data4);
        writer.flush();

    }
}
