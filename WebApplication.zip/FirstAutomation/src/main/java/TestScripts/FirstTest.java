/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author aman
 */
public class FirstTest {
    public static void main(String[] args) {
        //lunch browser (chrome) 1st import chrome driver 
        //ChromeDriver driver = new ChromeDriver();
        WebDriver driver = new ChromeDriver();
        
        //open url in browser
        driver.get("http://localhost:7072/#/Login");
        
        //validate the title
        String act_title = driver.getTitle();
        if(act_title.equals("Sigma - Pivotech Nepal"))
        {
          System.out.println("Title Matched");
        }
        else
        {
           System.out.println("Title didn't matched");
        }
        
        //to maximize the window 
        driver.manage().window().maximize();
        
        //close driver 
        //driver.quit();
        //driver.close();
        
        
    }
}
