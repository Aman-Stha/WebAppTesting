/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author aman
 */
public class HandleSSL {
    public static void main(String[] args) {
        
        ChromeOptions options = new ChromeOptions(); //every diver have their own options like EdgeOptions for Edge browser 
        options.setAcceptInsecureCerts(true); // this accepts SSL certificates like privacy error
        
        WebDriver driver = new ChromeDriver(options);
        driver.get("https://invtest.mfinplus.com/#/");
        
        String title = driver.getTitle();
        System.out.println(title);
        
    }
}
