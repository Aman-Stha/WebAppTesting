/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author aman
 */
public class HeadlessTesting {
    public static void main(String[] args) {
        
        //for headless testing
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new"); //setting for headless testing 
        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();

        
        driver.get("http://localhost:7072/#/Login");
        
        String act_title = driver.getTitle();
        if(act_title.equals("Sigma - Pivotech Nepal"))
        {
          System.out.println("Title Matched");
        }
        else
        {
           System.out.println("Title didn't matched");
        }
        
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito"); //to run our tests in incognito mode
        
        
        //close driver 
        //driver.quit();
        //driver.close();
        
        
    }
}
