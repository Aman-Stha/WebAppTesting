/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author aman
 */
public class HorizontalSlider {
    public static void main(String[] args) {
        
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
        driver.manage().window().maximize();
        
        Actions act = new Actions(driver);
        
        //Min --> Max
            WebElement min_slider = driver.findElement(By.xpath("//div[@class='price-range-block']//span[1]"));
            //Value of X axis and Y axis
            System.out.println("Location of slider: " + min_slider.getLocation()); //(X=58, Y=249)
            //We should use dragAndDropBy for slider where 100 is x axix and 249 is y axis
            act.dragAndDropBy(min_slider, 100, 249).perform();
        
        //Max --> Min
            WebElement max_slider = driver.findElement(By.xpath("//div[@class='price-range-block']//span[2]"));
            //Value of X axis and Y axis
            System.out.println("Location of slider: " + max_slider.getLocation()); //(X=876, Y=249)
            //We should use dragAndDropBy for slider where 100 is x axix and 0 is y axis
            act.dragAndDropBy(min_slider, -176, 249).perform();
    }
}
