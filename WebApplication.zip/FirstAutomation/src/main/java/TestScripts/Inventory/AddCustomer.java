/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class AddCustomer {
    public static void main(String[] args) throws InterruptedException{
        WebDriver driver = new ChromeDriver();
//        
//        driver.get("http://localhost:7072/#/Login");
//        
//        driver.manage().window().maximize();
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));   
//        
//        WebElement username = driver.findElement(By.xpath("//input[@id='username']"));
//        By password = By.xpath("//input[@id='password1']");
//        By signin = By.xpath("//button[@id='signIn']");
        By sales = By.xpath("//span[normalize-space()='Sales']");
        By customer = By.xpath("//span[normalize-space()='Customer']");
        By add = By.xpath("//span[normalize-space()='Add']");
        By name = By.xpath("//input[@placeholder='Enter Name']");
        By email = By.xpath("//input[@placeholder='Enter Email ']");
        By address = By.xpath("//input[@placeholder='Enter Address']");
        By phone = By.xpath("//input[@placeholder='Enter Phone Number']");
        By pan = By.xpath("//input[@placeholder='Enter Pan Number']");
        By save = By.xpath("//span[normalize-space()='Save Customer']");
        By list = By.xpath("//tr[@class='p-selectable-row p-highlight p-row-even']//td[@role='cell'][normalize-space()='999999999']");
        By delete = By.xpath("//button[@aria-label='Delete']");
        By yes = By.xpath("//span[normalize-space()='Yes']");
        
//        username.sendKeys("asus");
//        driver.findElement(password).sendKeys("nepal@123");
//        driver.findElement(signin).click(); 
        driver.findElement(sales).click();
        driver.findElement(customer).click();
        driver.findElement(add).click();
        driver.findElement(name).sendKeys("anyone");
        driver.findElement(email).sendKeys("anyone@gmail.com");
        driver.findElement(address).sendKeys("anywhere");
        driver.findElement(phone).sendKeys("9876567876");
        driver.findElement(pan).sendKeys("999999999");
        WebElement cramount = driver.findElement(By.xpath("//span[@aria-describedby='creditAmountHelp']//input[@role='spinbutton']"));
                Thread.sleep(1000);
                cramount.click();
                cramount.clear();
                cramount.sendKeys("12000");
            
            WebElement crlimit = driver.findElement(By.xpath("//span[@aria-describedby='creditLimitHelp']//input[@role='spinbutton']"));
                Thread.sleep(1000);
                crlimit.click();
                crlimit.clear();
                crlimit.sendKeys("12000");
        driver.findElement(save).click();
        
        //delete customer
//        driver.findElement(list).click();
//        driver.findElement(delete).click();
//        driver.findElement(yes).click();
                
    }
}
