/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class AddPurchase {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        
        //open url in browser
        driver.get("http://localhost:7072/#/Login");
        
        //to maximize the window 
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));  
            //this is applicable for all test scripts in this class
            //it is active till we close our driver 
            //we need to specify it on top 
            
        
        By username = By.xpath("//input[@id='username']");
        By purchase = By.xpath("//a[@id='pnl_Purchase']");
        By porder = By.xpath("//a[@id='subpnl_Purchase_Order']");
        By orderadd = By.xpath("//button[@aria-label='Add']");
        By supplier = By.xpath("//input[@placeholder='Select Supplier']");
        By product = By.xpath("//input[@id='selectedProduct1']");
        By confirm = By.xpath("//button[@aria-label='Confirm Purchase Order']");
        By advance = By.xpath("//span[@aria-describedby='paidAmountHelp']//input[@role='spinbutton']");
        By save = By.xpath("//span[normalize-space()='Save']");
        
        
        
        
        driver.findElement(username).sendKeys("asus");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("input#password1")).sendKeys("nepal@123");
        driver.findElement(By.cssSelector("button#signIn")).click(); 
        //Thread.sleep(10000);
        
        driver.findElement(purchase).click();
        driver.findElement(porder).click();
        driver.findElement(orderadd).click();
        Thread.sleep(5000);
        driver.findElement(supplier).click();
        driver.findElement(By.xpath("//li[@aria-label='Amrita Thapa [6985380268]']")).click();
        driver.findElement(product).click();
        driver.findElement(By.xpath("//li[@aria-label='8848 vodka [13633]']")).click();
        Thread.sleep(5000);
        driver.findElement(confirm).click();
        driver.findElement(advance).clear();
        driver.findElement(advance).sendKeys("100");
        Thread.sleep(5000);
        driver.findElement(save).click();
        
    }
}
