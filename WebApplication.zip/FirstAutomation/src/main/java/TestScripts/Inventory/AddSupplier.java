/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class AddSupplier {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();

        driver.get("http://localhost:7072/#/Login");

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));          
        
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        By purchase = By.xpath("//a[@id='pnl_Purchase']");    
        By supplier = By.xpath("//span[@class='ml-3 text-color'][normalize-space()='Supplier']");
        By add = By.xpath("//span[normalize-space()='Add']");
        By name = By.xpath("//input[@name='name']");
        By email = By.xpath("//input[@name='email']");
        By address = By.xpath("//input[@name='address']");
        By phone = By.xpath("//input[@name='phoneNo']");
        By pan = By.xpath("//input[@name='panNo']");
        By save = By.xpath("//span[normalize-space()='Save Supplier']");
        
        driver.findElement(username).sendKeys("asus");
        driver.findElement(password).sendKeys("nepal@123");
        driver.findElement(signin).click(); 
        driver.findElement(purchase).click();   
        driver.findElement(supplier).click();
        driver.findElement(add).click();
        driver.findElement(name).sendKeys("anybody");
        driver.findElement(email).sendKeys("anybody@gmail.com");
        driver.findElement(address).sendKeys("anywhere");
        driver.findElement(phone).sendKeys("9867876543");
        driver.findElement(pan).sendKeys("111111111");
        driver.findElement(save).click();
        
    }
}
