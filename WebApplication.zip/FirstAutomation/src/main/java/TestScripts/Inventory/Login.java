/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class Login {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        
        driver.get("http://localhost:7072/#/Login");
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));   
        
        Thread.sleep(3000);
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        By toast = By.xpath("//div[@class='p-toast-message-content']");
        
        driver.findElement(username).sendKeys("asus");
        driver.findElement(password).sendKeys("nepal@123");
        driver.findElement(signin).click(); 
        
        Thread.sleep(2000);
        String logText = driver.findElement(toast).getText();
        System.out.println(logText);
        
        if(logText.equals("Successfully LoggedIn !!")) {
            System.out.println("Login successfull");
        } else {
            System.out.println("Login failed");
        }
        
    }
}
