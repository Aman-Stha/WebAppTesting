/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class LoginCSV {
    public static void main(String[] args) throws InterruptedException, FileNotFoundException, IOException, CsvValidationException {
        
         WebDriver driver = new ChromeDriver();      
            
            CSVReader reader = new CSVReader(new FileReader("/home/aman/Users/Jmeter/CSV/login.csv"));
            reader.readNext();
            String[] str;
            
            while((str=reader.readNext())!=null){
                for(String s : str) {
                    System.out.print(s+" ");
                }
                System.out.println();

                String username = str[0];
                String password = str[1];

                
                try {
                    driver.get("http://localhost:7072/#/Login");
                    driver.manage().window().maximize();
                    
                    driver.navigate().refresh();
                    
                    Thread.sleep(2000);
                    driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
                    driver.findElement(By.xpath("//input[@id='password1']")).sendKeys(password);
                    driver.findElement(By.cssSelector("button#signIn")).click();
                    Thread.sleep(1000);
                    
                    By toast = By.xpath("//div[@class='p-toast-message-content']");
                    Thread.sleep(1000);
                    String logText = driver.findElement(toast).getText();
                    System.out.println(logText);
                    
                    Thread.sleep(10000);
                    driver.findElement(By.xpath("//button[@title='User Profile']")).click();
                    Thread.sleep(1000);
                    driver.findElement(By.xpath("//span[normalize-space()='Log Out']")).click();
                    //sign out only needed when multiple users are passed

                } catch (Exception e) {
                    // If an error occurs during login, print error message and continue to the next iteration
                   System.out.println("Error occured: " + e.getMessage());
                }
                
            }
    }
}
