/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.security.Key;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class ViewProductTable {
public static void main(String[] args) throws InterruptedException {
        
        //running FirstTest.java file 
        //FirstTest.main(new String[]{});
        
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        
        //open url in browser
        driver.get("http://localhost:7072/#/Login");
        
        //to maximize the window 
        driver.manage().window().maximize();
        
        //using variable as a locator for elements
        By username = By.xpath("//input[@id='username']");
        driver.findElement(username).sendKeys("asus");
        driver.findElement(By.cssSelector("input#password1")).sendKeys("nepal@123");
        driver.findElement(By.cssSelector("button#signIn")).click(); 
         
        driver.findElement(By.cssSelector("a#pnl_Product")).click();
        driver.findElement(By.cssSelector("a#subpnl_Product_Details")).click();
        Thread.sleep(10000);

        WebElement search = driver.findElement(By.xpath("//th[1]//div[1]//div[1]//input[1]"));
        search.sendKeys("blue");
        search.sendKeys(Keys.ENTER);
        

    }    
}
