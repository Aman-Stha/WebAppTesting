/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class JavaScriptExecuterDemo {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://testautomationpractice.blogspot.com/");
        driver.manage().window().maximize();
        
        WebElement input1 = driver.findElement(By.xpath("//input[@id='name']"));
        
        //When we use WebDriver then we have to do typecasting for javascript executor 
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].setAttribute('value','John')",input1); //for sending keys
        
        WebElement radioBtn = driver.findElement(By.xpath("//input[@id='male']")); //for clicking actions 
        js.executeScript("arguments[0].click()", radioBtn);
        
//      When we use ChromerDriver then we can directly use javascript executor without typecasting
//        ChromeDriver driver1 = new ChromeDriver();
//        JavascriptExecutor js1 = driver1;
        
        
        //Scrolling page
            JavascriptExecutor js1 = (JavascriptExecutor)driver;
            
            // 1) Scroll by pixel number
            js1.executeScript("window.scrollBy(0, 3000)", ""); // 0  is starting value and 3000 is ending value
            System.out.println(js.executeScript("return window.pageYOffset;")); // to print how many pixels it moved to 
            
            // 2) Scroll till element is visible 
            WebElement ele = driver.findElement(By.xpath("give path"));
            js1.executeScript("arguments[0].scrollIntoView();", ele);
            System.out.println(js.executeScript("return window.pageYOffset;")); // to print how many pixels it moved to 
            
            //3) Scroll till bottom of the page
            js1.executeScript("window.scrollBy(0, document.body.scrollHeight)");// it will go to bottom of page 
            System.out.println(js.executeScript("return window.pageYOffset;"));
            //scroll back to top
            js1.executeScript("window.scrollBy(0, -document.body.scrollHeight)"); // it will go to top of page
            
        //Controlling zoom level
            js1.executeScript("document.body.style.zoom='50%'"); //zoom level 50%
            Thread.sleep(3000);
            js1.executeScript("document.body.style.zoom='80%'"); //zoom level 80%

            
    }
}
