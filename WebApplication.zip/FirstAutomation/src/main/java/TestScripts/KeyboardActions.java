/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author aman
 */
public class KeyboardActions {
    public static void main(String[] args) {
        
        WebDriver driver = new ChromeDriver();
        driver.get("https://text-compare.com");
        driver.manage().window().maximize();
        
        driver.findElement(By.xpath("//textarea[@id='inputText1']")).sendKeys("WELCOME");
        
        Actions act = new Actions(driver);
        
        //Ctrl + A 
            act.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform(); 
            //keyDown is for pressing key and keyUp is for releasing the key 
            //For A-Z we use sendKeys
        
        //Ctrl + C
            act.keyDown(Keys.CONTROL).sendKeys("C").keyUp(Keys.CONTROL).perform(); 

        //Tab 
            act.keyDown(Keys.TAB).keyUp(Keys.TAB).perform();
        
        //Ctrl + v
            act.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).perform(); 
        
    }
}
