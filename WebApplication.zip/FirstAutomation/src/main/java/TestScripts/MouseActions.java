/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author aman
 */
public class MouseActions {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://demo.opencart.com/");
        driver.manage().window().maximize();
        
        WebElement desktops = driver.findElement(By.xpath("//a[normalize-space()='Desktops']"));
        WebElement mac = driver.findElement(By.xpath("//a[normalize-space()='Mac (1)']"));

        Actions act = new Actions(driver);
        
    //Mouse Hover
        // we use moveToElement(...element...) to perform mouse hover action
        //act.moveToElement(desktops).moveToElement(mac).click().build().perform();
        act.moveToElement(desktops).moveToElement(mac).click().perform(); //perform will do both build and perform action
        
        
    //Right Click
        // we use contextClick(...element...) to perform right click action
        WebElement button = driver.findElement(By.xpath("give xpath"));
        act.contextClick(button).perform(); // after using Actions we should always use .perform() 
        
    //Double Click 
        //we use doubleClick(...element...) to perform double click action
        WebElement btn1 = driver.findElement(By.xpath("give xpath"));
        act.doubleClick(btn1).perform();
        
    //Drag and drop 
        //we use dragAndDrop(source, target) to perform drag and drop action
        WebElement source = driver.findElement(By.xpath("give xpath"));
        WebElement target = driver.findElement(By.xpath("give xpath"));
        act.dragAndDrop(source, target).perform();
        
    }
}
