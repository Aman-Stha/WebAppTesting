/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class UploadingFiles {
    public static void main(String[] args) {
        
        WebDriver driver = new ChromeDriver();
        driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
        driver.manage().window().maximize();
        
        WebElement upload = driver.findElement(By.xpath("//input[@id='filesToUpload']"));
                
        //Single file upload 
        upload.sendKeys("..location of the file.. & ..name of the file..");
                
        //Multiple files upload
        String file1 = "..location of the file.. & ..name of the file..";
        String file2 = "..location of the file.. & ..name of the file..";
        upload.sendKeys(file1+"\n"+file2); // "\n" represents new line
        
    }
}
