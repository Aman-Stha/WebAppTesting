/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class BeforeMethodAnnotation {
    
    @BeforeMethod
    public void login() {
        System.out.println("Login successful");
    }
    
    @Test(priority = 1)
    public void search() {
        System.out.println("Searching...");

    }
    
    @Test(priority = 2)
    public void advanceSearch() {
        System.out.println("Advance Searching...");
    }
    
    @AfterMethod
    public void logout() {
        System.out.println("Logging Out");
    }
}
