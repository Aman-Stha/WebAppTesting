/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class DependencyMethods {
    
    @Test(priority = 1)
    public void open() { 
        Assert.assertTrue(true);
    }
    
    @Test(priority = 2, dependsOnMethods = "open")
    public void login() {
        Assert.assertTrue(true);
    }
    
    @Test(priority = 3, dependsOnMethods = "login")
    public void search() {
        Assert.assertTrue(true);
    }
    
    @Test(priority = 4, dependsOnMethods = {"login", "search"}) //both login and search methods should be passed to execute this method 
    public void advSearch() {
        Assert.assertTrue(true);
    }
    
    @Test(priority = 5, dependsOnMethods = "login") 
    public void logout() {
        Assert.assertTrue(true);
    }
}
