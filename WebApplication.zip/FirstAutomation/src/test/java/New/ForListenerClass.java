/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

/*
    if we want to use listener driectly from class without having xml file then we need write @Listener annotation 
    @Listeners(New.MyListenerClass.class)
    this approach is not preferred because we have to use this annotation in all the classes when there are multiple classes
*/

public class ForListenerClass {
    
    WebDriver driver;
    
    @BeforeClass
    void setup() throws InterruptedException {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        Thread.sleep(5000);
        
    }
    
    @Test(priority = 1)
    void testLogo() {
        
        boolean logo = driver.findElement(By.xpath("//button[@type='submit']")).isDisplayed();
        Assert.assertEquals(logo, true);
        
    }
    
    @Test(priority = 2)
    void testUrl() {
        
        Assert.assertEquals(driver.getCurrentUrl(), "https://opensource-demo.orangehrmlive.com/web/");
        
    }
    
    @Test(priority = 3, dependsOnMethods = "testUrl")
    void testTitle() {
        
        Assert.assertEquals(driver.getTitle(), "OrangeHRM");
        
    }
    
}
