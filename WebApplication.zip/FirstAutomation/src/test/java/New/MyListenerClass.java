/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 *
 * @author aman
 */
public class MyListenerClass implements ITestListener {
    
    //there are two ways to implement listener class
    // 1) By using (implements ITestListener)
    // 2) By using (extends ITestListenerAdapter)
    
    public void onStart(ITestContext context) {
        System.out.println("OnStart method is executed .... ");
    }
    
    public void onTestStart(ITestResult result) {
        System.out.println("OnTestStart method is executed .... ");   
    }

    public void onTestSuccess(ITestResult result) {
        System.out.println("Test passed");
    }
    
    public void onTestFailure(ITestResult result) {
        System.out.println("Test failed");    
    }

    public void onTestSkipped(ITestResult result) {
        System.out.println("Test skipped");
    }
       
    public void onFinish(ITestContext context) {
        System.out.println("Test finished");
    }
    
}
