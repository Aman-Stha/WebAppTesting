/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddPO {
    WebDriver driver;
    
    public AddPO(WebDriver driver) {
        this.driver = driver;
    }
    
    By purchase = By.xpath("//a[@id='pnl_Purchase']");
    By PO = By.xpath("//span[normalize-space()='Purchase Order']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By supplier = By.xpath("//input[@placeholder='Select Supplier']");
    By product = By.xpath("//input[@id='selectedProduct1']");
    By confirm = By.xpath("//button[@aria-label='Confirm Purchase Order']");
    By advance = By.xpath("//span[@aria-describedby='paidAmountHelp']//input[@role='spinbutton']");
    By save = By.xpath("//span[normalize-space()='Save']");
    
    public void POinput(String adv) throws InterruptedException { 
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        
        driver.findElement(purchase).click();
        driver.findElement(PO).click();
        driver.findElement(add).click();
        driver.findElement(supplier).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@aria-label='QAMcheck [9999999999]']"))).click();
        driver.findElement(product).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@aria-label='8848 vodka [13633]']"))).click();
        Thread.sleep(1000);
        driver.findElement(confirm).click();
        driver.findElement(advance).clear();
        driver.findElement(advance).sendKeys(adv);
        driver.findElement(save).click();
                        
    }
}
