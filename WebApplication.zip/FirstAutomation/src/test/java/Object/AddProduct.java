/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddProduct {
    
    WebDriver driver;
    public AddProduct(WebDriver driver) {
        this.driver = driver;
    }
    
    By clickProduct = By.xpath("//a[@id='pnl_Product']");
    By subProduct = By.xpath("//span[normalize-space()='Product Details']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By pname = By.xpath("//input[@id='name']");
    By pcode = By.xpath("//input[@id='code']");
    By grpcode = By.xpath("//input[@id='groupCode']");
    By pcategory = By.xpath("//div[@id='category']//button[@type='button']//*[name()='svg']");
    By punit = By.xpath("//div[@id='unitGroup']//button[@type='button']//*[name()='svg']");
    By next1 = By.xpath("//button[@id='btn_basic_next']"); 
    
    
    public void Pinput(String pn, String pc, String gc) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(clickProduct)).click();
        wait.until(ExpectedConditions.elementToBeClickable(subProduct)).click();
        wait.until(ExpectedConditions.elementToBeClickable(add)).click();
        driver.findElement(pname).sendKeys(pn);
        driver.findElement(pcode).sendKeys(pc);
        driver.findElement(grpcode).sendKeys(gc);
        driver.findElement(pcategory).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@id='category_7']"))).click();
        driver.findElement(punit).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@id='unitGroup_2']"))).click();
        driver.findElement(next1).click();
    }
}
