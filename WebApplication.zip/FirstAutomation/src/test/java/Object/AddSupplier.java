/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddSupplier {
    WebDriver driver;
    public AddSupplier(WebDriver driver){
        this.driver = driver;
    }
    
    By purchase = By.xpath("//a[@id='pnl_Purchase']");    
    By supplier = By.xpath("//span[@class='ml-3 text-color'][normalize-space()='Supplier']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By name = By.xpath("//input[@name='name']");
    By email = By.xpath("//input[@name='email']");
    By address = By.xpath("//input[@name='address']");
    By phone = By.xpath("//input[@name='phoneNo']");
    By pan = By.xpath("//input[@name='panNo']");
    By save = By.xpath("//span[normalize-space()='Save Supplier']");
    
    public void Sinput(String nam, String ema, String addr, String call, String pn){
        
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        
        wait.until(ExpectedConditions.elementToBeClickable(purchase)).click();   
        wait.until(ExpectedConditions.elementToBeClickable(supplier)).click();
        wait.until(ExpectedConditions.elementToBeClickable(add)).click();
        driver.findElement(name).sendKeys(nam);
        driver.findElement(email).sendKeys(ema);
        driver.findElement(address).sendKeys(addr);
        driver.findElement(phone).sendKeys(call);
        driver.findElement(pan).sendKeys(pn);
        driver.findElement(save).click();
    }
}
