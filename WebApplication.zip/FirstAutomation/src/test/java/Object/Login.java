/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author aman
 */
public class Login {
    
    WebDriver driver;
    
    public Login(WebDriver driver){
        this.driver = driver;
    }
    
    By username = By.xpath("//input[@id='username']");
    By password = By.xpath("//input[@id='password1']");
    By signin = By.xpath("//button[@id='signIn']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");
        
    public void input(String uname, String pw) throws InterruptedException {
        driver.findElement(username).sendKeys(uname);
        driver.findElement(password).sendKeys(pw);
        driver.findElement(signin).click();
        Thread.sleep(3000);
        driver.findElement(toast).getText();
    }
}
