/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Page;

import Object.AddPO;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Object.Login;
import Object.AddProduct;
import Object.AddSupplier;

/**
 *
 * @author aman
 */
public class LoginTest {
    
    WebDriver driver;  
    
    @BeforeTest
    public void beforeTest() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        
        driver.get("http://localhost:7072/#/Login");
    }
    
    @Test
    public void loginOperation() {
        try {
                Login page = new Login(driver);
                page.input("asus", "nepal@123");            
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
    }
    
    /*
    
    @Test(dependsOnMethods = "loginOperation")
    public void addProductOperation() {
       try {
            AddProduct pg = new AddProduct(driver);
            pg.Pinput("pom","pom11","pom22");
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());            
        }
    }
    
    */
    
    @Test
    public void addSupplierOperation() {
        try {
            AddSupplier pg = new AddSupplier(driver);
            pg.Sinput("sami123", "sami@gmail.com", "patan", "9803841526", "123551123");
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    
    @Test
    public void addPO() { 
        try {
            AddPO pg = new AddPO(driver);
            pg.POinput("0");
        } catch (Exception e) {
            System.err.println("Error " + e.getMessage());
        }
    }
    
    @AfterTest
    public void afterTest() {
        //driver.quit();
    }
}
